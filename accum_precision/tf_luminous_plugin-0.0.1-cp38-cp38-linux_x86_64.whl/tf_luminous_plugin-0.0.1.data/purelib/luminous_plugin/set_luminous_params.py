import enum
import tensorflow as tf

from pathlib import Path
from typing import Optional

_MODULE = tf.load_op_library(str(Path(__file__).parent / "luminous_ops.so"))


class PluginLogLevel(enum.IntEnum):
    DEBUG = -1
    INFO = enum.auto()
    WARNING = enum.auto()
    ERROR = enum.auto()
    FATAL = enum.auto()


def set_luminous_params(
    *,
    bfloat16_acc_bits: Optional[int] = None,
    log_level: Optional[PluginLogLevel] = None,
):
    if bfloat16_acc_bits is None:
        bfloat16_acc_bits = []
    elif bfloat16_acc_bits < 0:
        raise ValueError(
            f"bfloat16_acc_bits must be a non-negative integer, got {bfloat16_acc_bits}"
        )

    log_level = [] if log_level is None else log_level.value

    kwargs = dict(bfloat16_acc_bits=bfloat16_acc_bits, log_level=log_level)
    _MODULE.set_luminous_params(**kwargs)
